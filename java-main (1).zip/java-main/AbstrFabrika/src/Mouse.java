public interface Mouse {
    void click();
    void dblclick();
    void scroll(int direction);
}
