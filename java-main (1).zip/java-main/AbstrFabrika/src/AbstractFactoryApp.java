public class AbstractFactoryApp {
    public static void main(String[] args) {
DeviceFactory factory = getFactoryByCountryCode("EN");
Mouse   m = factory.getMouse();
Keyboard    k = factory.getKeyboard();
Touchpad    t = factory.getTouchpad();

m.click();
k.print();
t.track(10,37);

    }
private static DeviceFactory getFactoryByCountryCode(String lang){
        switch (lang){
            case "RU":
                return new RuDeviceFactory();
            case "EN":
                return new EnDeviceFactory();
            default:
                throw new RuntimeException("Unsupported Country Code:" + lang);
        }
}}

