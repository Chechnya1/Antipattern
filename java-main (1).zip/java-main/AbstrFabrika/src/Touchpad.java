public interface Touchpad {
    void track(int deltaX, int deltaY);
}
