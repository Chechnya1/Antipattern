public interface Keyboard {
    void print();
    void println();
}
