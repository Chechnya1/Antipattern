public interface Logger {
    void writeMessage(String message, int level);
}
